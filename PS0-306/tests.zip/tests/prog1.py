from otter.test_files import test_case

OK_FORMAT = False

name = "prog1"
points = 15

@test_case(points=5, hidden=False, 
    success_message="Tests for n < 20 passed!", 
    failure_message="Tests for n < 20 failed!")
def test_small_primes(is_prime):
    assert is_prime(1) == False
    assert is_prime(2) == True
    assert is_prime(7) == True
    assert is_prime(12) == False
    assert is_prime(15) == False
    assert is_prime(19) == True
    return


@test_case(points=5, hidden=False, 
    success_message="Tests for n < 50 passed!", 
    failure_message="Tests for n < 50 failed!")
def test_medium_primes(is_prime):
    assert is_prime(49) == False
    assert is_prime(43) == True
    assert is_prime(31) == True
    assert is_prime(39) == False
    assert is_prime(48) == False
    assert is_prime(37) == True
    assert is_prime(29) == True
    return

@test_case(points=5, hidden=False, 
    success_message="Tests for n > 1000 passed!", 
    failure_message="Tests for n > 1000 failed!")
def test_large_primes(is_prime):
    assert is_prime(421) == True
    assert is_prime(1223) == True
    assert is_prime(439787) == True
    assert is_prime(439789) == False
    assert is_prime(112755) == False
    assert is_prime(11277157) == False
    return

