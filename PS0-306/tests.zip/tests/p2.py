from otter.test_files import test_case

OK_FORMAT = False

name = "p2"
points = 15

@test_case(points=5, hidden=False)
def test_stats_small(calculate_stats):
    import math
    
    assert math.isclose(calculate_stats([10, 10, 10, 10])[0], 10)  # mean
    assert math.isclose(calculate_stats([10, 10, 10, 10])[1], 10)  # median
    assert math.isclose(calculate_stats([10, 10, 10, 10])[2], 0)   # std dev

    assert math.isclose(calculate_stats([10, 20, 30, 40])[0], 25)  # mean
    assert math.isclose(calculate_stats([10, 20, 30, 40])[1], 25)  # median
    assert math.isclose(calculate_stats([10, 20, 30, 40])[2], 12.9099, abs_tol=0.001)   # std dev
    return

