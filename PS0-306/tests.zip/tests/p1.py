from otter.test_files import test_case

OK_FORMAT = False

name = "p1"
points = 15

@test_case(points=5, hidden=False, 
    success_message="Tests for n < 20 passed!", 
    failure_message="Tests for n < 20 failed!")
def test_small_primes(is_prime):
    assert is_prime(1) == False
    assert is_prime(2) == True
    assert is_prime(7) == True
    assert is_prime(12) == False
    assert is_prime(15) == False
    assert is_prime(19) == True
    return

