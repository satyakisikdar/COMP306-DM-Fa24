from otter.test_files import test_case

OK_FORMAT = False

name = "q1"
points = 5

@test_case(points=None, hidden=False)
def test1(square):
  assert square(1) == 1

@test_case(points=None, hidden=False)
def test2(square):
  assert square(0) == 0

