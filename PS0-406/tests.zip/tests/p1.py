from otter.test_files import test_case

OK_FORMAT = False

name = "p1"
points = 15

@test_case(points=5, hidden=False)
def test_low_primes(sieve):
    assert sieve(1) == set()
    assert sieve(2) == {2}
    assert sieve(3) == {2, 3}

