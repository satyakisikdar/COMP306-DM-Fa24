from otter.test_files import test_case

OK_FORMAT = False

name = "p2"
points = 15

@test_case(points=5, hidden=False)
def test(data):
    assert len(data["flavor"].unique()) == 4 

@test_case(points=5, hidden=False)
def test(data):
    for l in ["chocolate", "vanilla", "strawberry", "mint"]:
        assert l in data["flavor"].unique()

